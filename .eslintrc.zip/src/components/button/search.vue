<template>
  <el-button>
    <i class="el-icon-search"></i>
    <span>查询</span>
  </el-button>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style lang="less" scoped>
.el-button {
  color:#fff;
  background-color: #5f84ff;
}
</style>
