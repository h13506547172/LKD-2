<template>
  <el-button>
    <i class="el-icon-circle-plus-outline"></i>
    <span>新建</span>
  </el-button>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style lang="less" scoped>
.el-button {
  color:#fff;
  background: linear-gradient(135deg,#ff9743,#ff5e20)!important;
}
</style>
