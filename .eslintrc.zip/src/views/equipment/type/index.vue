<template>
  <div>设备类型管理</div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style lang="less" scoped></style>
