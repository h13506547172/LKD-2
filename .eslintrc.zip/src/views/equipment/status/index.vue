<template>
  <div>设备状态</div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style lang="less" scoped></style>
