<template>
  <div>
    运维工单
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  },

  created () {

  },

  methods: {

  }
}
</script>

<style lang='less' scoped>

</style>
