<template>
  <div class="dashboard-container">
    <div class="app-container">
      <!-- header -->
      <div class="header">
        <div class="day">11</div>
        <div class="day">22</div>
      </div>
      <!-- nav -->
      <div class="nav">33</div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style lang="less" scoped>
.app-container {
  padding: 20px 15px 19px 17px;
  background-color: #fff;
  min-height: 700px;
}
</style>
