<template>
  <div>
    合作商管理
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  },

  created () {

  },

  methods: {

  }
}
</script>

<style lang='less' scoped>

</style>
